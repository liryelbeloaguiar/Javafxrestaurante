package poo.restaurante;

public class Cliente extends Pessoa {
    private Integer reserva;

    public Cliente(String nome, Integer idade, String contato) {
        super(nome, idade, contato);
    }
}
