package poo.restaurante;

import java.util.ArrayList;
import java.util.List;

public class FachadaMesas {
    public List<Mesa> mesasLivres = new ArrayList<>();
    public List<Mesa> mesasOcupadas = new ArrayList<>();
    public List<Mesa> mesasReservadas = new ArrayList<>();

    public FachadaMesas() {

    }



}
